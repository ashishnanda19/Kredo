# Kredo mobile app — entire project

This project’s pages, files, and uploads as this browser tab had them at export.
Anything left out is listed below.

## Contents

- `Activity.dc.html`
- `Aura.dc.html`
- `Blocked.dc.html`
- `Dues.dc.html`
- `Help.dc.html`
- `Join.dc.html`
- `Limit.dc.html`
- `Loan.dc.html`
- `Login.dc.html`
- `Main.dc.html`
- `Notifications.dc.html`
- `Otp.dc.html`
- `OtpJoin.dc.html`
- `Paid.dc.html`
- `Passport.dc.html`
- `Pay.dc.html`
- `Privacy.dc.html`
- `Profile.dc.html`
- `Quests.dc.html`
- `Receipt.dc.html`
- `Repaid.dc.html`
- `Repay.dc.html`
- `Reviewing.dc.html`
- `Scan.dc.html`
- `Splash.dc.html`
- `Unlocked.dc.html`
- `VDetails.dc.html`
- `VInsights.dc.html`
- `VLive.dc.html`
- `VPayments.dc.html`
- `VProfile.dc.html`
- `VQr.dc.html`
- `VReceived.dc.html`
- `VReviewing.dc.html`
- `VSettle.dc.html`
- `VToday.dc.html`
- `VVerify.dc.html`
- `VWelcome.dc.html`
- `Verify.dc.html`
- `Welcome.dc.html`
- `canvas.json` — the canvas: its pages, where each artboard sits, its notes and shapes
- `_runtime/` — what runs the pages in a browser; not part of the design

## Viewing

To view a page, start a local web server in this folder (for example `python3 -m http.server`), then open an artboard’s `.dc.html` file through it. Opening the file directly may not work, because some browsers block its scripts.

## Left out of this export

The export never includes hidden files (files whose names start with a dot) or
files the editor keeps for its own use.
